# -*- coding: utf-8 -*-
"""
Created on Tue May 22 21:02:08 2018
1.函数的定义,有四个部分:def,函数名,(参数列表),函数体
2.函数的使用，2个部分。函数名(参数列表)
3.函数的参数：2种。形式参数，实体参数
4.我们以前使用过哪些系统的函数
@author: yq
"""
def abc():#函数的定义
    print('执行了abc函数')

abc()#函数的调用


def calc(a,b):#定义函数的参数列表叫，形式参数
    s=a+b
#    print("a和b的和是：",s)
    return s

x=calc(3,4)#实体参数
print(x)

"""
1.系统的内置函数。
2.外部的函数（可以从python外部模块导入）
"""
sum([3,4])
max([1,2,8,3])

import urllib.request as r#外部的py文件

res=r.urlopen(url='http://www.baidu.com')
res.getcode()


from urllib import request

request.urlopen('http://www.baidu.com')







    

