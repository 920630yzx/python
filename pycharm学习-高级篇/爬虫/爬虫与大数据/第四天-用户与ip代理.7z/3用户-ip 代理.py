# -*- coding: utf-8 -*-
"""
Created on Tue May 22 21:42:21 2018
用户   存在header里面
ip
代理
@author: yq
"""
import random
#用户代理池
uas=['Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36',
     'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko',
     'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)']

#123.119.120.110
"""
113.200.214.164	9999	陕西西安
125.46.0.62	53281	河南济源
114.250.25.19	80	北京
123.161.16.20	9797	河南安阳
114.215.95.188	3128	北京
"""
#ip代理池
ips=['113.200.214.164:9999',
     '125.46.0.62	53281',
     '114.250.25.19:80',
     '123.161.16.20:9797',
     '114.215.95.188:3128']


import urllib.request as r
url='http://weixin.sogou.com/'
header={'user-agent':random.choice(uas)}

ipproxy(ips)#设置ip代理上网
req=r.Request(url,header)
data=r.urlopen(url).read()
len(data)


#Proxy代理
import urllib.request as r
def ipproxy(ips):
    ip=random.choice(ips)
    print('IP地址',ip)
    proxy=r.ProxyHandler({'http':ip})
    opener=r.build_opener(proxy,r.HTTPHandler)
    r.install_opener(opener)










