# -*- coding: utf-8 -*-
"""
Created on Tue May 22 20:40:01 2018
y是在abc():里面定义的，
属于2.局部变量。作用域在abc里面

@author: yq
"""
x=10#1.全局变量，从程序的开始，到最后都可以使用
def abc():
    global y#只有当运行只有才会变为3.全局global变量
    y=10
    y=y+1
    print(y)

print(x)
abc()
print(y)


